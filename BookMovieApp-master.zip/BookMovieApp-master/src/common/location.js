let location = [
    {
      id: 1,
      location: "Bengaluru"
    },
    {
      id: 2,
      location: "Mumbai"
    },
    {
      id: 3,
      location: "Delhi"
    },
    {
      id: 4,
      location: "Kolkatta"
    },
    {
      id: 5,
      location: "Chennai"
    }
  ]
  
  export default location;